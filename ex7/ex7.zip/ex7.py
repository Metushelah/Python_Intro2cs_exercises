from SolveLinear3 import solve_linear_3


def is_point_inside_triangle(point, v1, v2, v3):
    pass


def create_triangles(list_of_points):
    pass


def do_triangle_lists_match(list_of_points1, list_of_points2):
    pass


def get_point_in_segment(p1, p2, alpha):
    pass


def get_intermediate_triangles(source_triangles_list, target_triangles_list,
                                                                  alpha):
    pass

# until here should be submitted by next week - 18.12.2014


def get_array_of_matching_points(size,triangles_list ,
                                 intermediate_triangles_list):
    pass


def create_intermediate_image(alpha, size, source_image, target_image,
                              source_triangles_list, target_triangles_list):
    pass


def create_sequence_of_images(size, source_image, target_image, 
                source_triangles_list, target_triangles_list, num_frames):
    pass


# until here should be submitted by 25.12.2014