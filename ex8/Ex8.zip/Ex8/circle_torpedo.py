# FILE: -----------.py
# WRITER : konstantin, guybrush, 30888377
# EXERCISE : intro2cs ---------- 2014-2015
# DESCRIPTION:
# ------------------------
# ------------------------

import math
from baseObject import BaseObject
from objectShapes import TORPEDO_SHAPE

class CircleTorpedo(BaseObject):

    RADIUS = 4
    CIRCLE_RADIUS = 20
    TORPEDO_LIFESPAN = 200

    def __init__(self,canvas,x,y,dx,dy,direction):
        super().__init__(canvas,x,y,dx,dy,TORPEDO_SHAPE,direction,CircleTorpedo.RADIUS)
        # 2 pi r / (sqrt(dx ** 2 + dy ** 2) * TORPEDO_LIFESPAN)
        self.set_color("Green")
        self.lifespan = CircleTorpedo.TORPEDO_LIFESPAN

    def get_life_span(self):
        return self.lifespan

    def move(self,x,y):
        self.lifespan = self.lifespan - 1
        super().move(x,y)



    #_______________ put this in asteroidMain and add in init
    def _bind_key_o(self):
        self.game.get_original_game_handler().bind_key("o", self._handle_o)


    def _handle_o(self):
        self._o_Clicks += 1

    def is_o_pressed(self):
        """
        :returns: True if the fire key was pressed, else False
        """
        res = self._o_Clicks > 0
        self._o_Clicks -= 1 if res else 0
        return res


"""
    need to create such a function to add and delete new circle torpedoes


    def add_torpedo(self, x,y,xSpeed,ySpeed,angle):
        ""
        This adds a torpedo into the game

        :param x: The x coordinate of the torpedo.
        :type x: int
        :param y: The y coordinate of the torpedo.
        :type y: int
        :param xSpeed: The current speed on the x direction.
        :type xSpeed: int
        :param ySpeed: The current speed on the y direction.
        :type ySpeed: int
        :param angle: The angle the torpedo is headed to
        :type angle: int
        ""
        torpedo = PhotonTorpedo(self._cv, x,y,xSpeed,ySpeed,angle)
        self.torpedos.append(torpedo)

        def remove_torpedos(self, deadtorpedos):
        ""
        Removes the given list of dead torpedos from our live torpedos list

        :param deadtorpedos: The list of dead torpedos.
        :type deadtorpedos: list
        ""
        for torpedo in deadtorpedos:
            try:
                self.torpedos.remove(torpedo)
            except:
                pass#print("didn't find torpedo")

            torpedo.goto(-self.get_screen_min_x()*2, -self.get_screen_min_y()*2)
            torpedo.ht()
"""

